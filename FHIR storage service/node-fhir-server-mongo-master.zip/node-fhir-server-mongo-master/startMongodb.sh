!/bin/bash
mkdir -p storageMongodb1
mongod -dbpath storageMongodb1
