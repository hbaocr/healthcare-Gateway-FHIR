### Do you want to request a feature, improve documentation, or ask a question?

### Are you reporting a bug?

**What is the current behavior?**

**What is the expected behavior?**

**What are the steps to reproduce?**

**What OS are you using and what version of node.js, @asymmetrik/node-fhir-server-core, and @asymmetrik/node-fhir-server-mongo are you running?**
